class ContactController < ApplicationController
  def index
  end
end
