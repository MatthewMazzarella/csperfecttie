class RegisterController < ApplicationController
  def index
  end
end
