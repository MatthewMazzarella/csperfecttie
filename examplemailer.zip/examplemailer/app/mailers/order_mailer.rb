class OrderMailer < ApplicationMailer
  default from: "jediknight668@gmail.com"

  def sample_email(user)
    @user = user
    mail(to: @user.email, subject: 'Confirmation Email')
  end
end
